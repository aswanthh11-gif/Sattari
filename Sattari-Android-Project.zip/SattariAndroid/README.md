# Sattari Android app project

This packages the Sattari web app as a native Android application shell using Android WebView. It supports local storage, profile photos and document/photo selection through Android's file picker.

## Build APK
Open this folder in Android Studio, let Gradle sync, then choose Build > Build APK(s). The debug APK will be under `app/build/outputs/apk/debug/`.

This is a prototype. Do not use it for real medical data until a secure backend, authentication, encryption, access control, consent-based sharing, backups, and applicable privacy/compliance work are implemented.
