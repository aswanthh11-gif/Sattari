const KEY="sattari_v1";
const $=id=>document.getElementById(id);
let state=JSON.parse(localStorage.getItem(KEY)||"null")||{user:null,records:[],checkups:[],vaccines:[],appointments:[]};

function save(){localStorage.setItem(KEY,JSON.stringify(state));renderAll()}
function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function fmtDate(v){if(!v)return "—"; return new Date(v+"T00:00:00").toLocaleDateString(undefined,{day:"numeric",month:"short",year:"numeric"})}
function fmtDateTime(d,t){if(!d)return "—"; return fmtDate(d)+(t?" · "+t:"")}
function initials(name){return (name||"S").split(/\s+/).slice(0,2).map(x=>x[0]).join("").toUpperCase()}
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2200)}
function openModal(html){$("modalContent").innerHTML=html;$("modal").classList.remove("hidden")}
function closeModal(){$("modal").classList.add("hidden")}
$("closeModal").onclick=closeModal;
$("modal").querySelector(".modal-backdrop").onclick=closeModal;

function showPage(page){
  document.querySelectorAll(".page").forEach(p=>p.classList.add("hidden"));
  $("page-"+page).classList.remove("hidden");
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  $("pageTitle").textContent={dashboard:"Overview",records:"Health records",checkups:"Upcoming checkups",vaccines:"Vaccinations",appointments:"Appointments",profile:"Your profile"}[page];
  document.querySelector(".sidebar").classList.remove("open");
}
document.querySelectorAll(".nav-item").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
document.querySelectorAll("[data-page-jump]").forEach(b=>b.onclick=()=>showPage(b.dataset.pageJump));
$("mobileMenu").onclick=()=>document.querySelector(".sidebar").classList.toggle("open");

function renderHeader(){
  const u=state.user;if(!u)return;
  $("welcomeName").textContent=`Good to see you, ${u.name.split(" ")[0]}.`;
  $("topProfile").innerHTML=`<div>${esc(u.name)}</div><div class="avatar">${u.photo?`<img src="${u.photo}" class="avatar">`:esc(initials(u.name))}</div>`;
}
function renderDashboard(){
  $("statRecords").textContent=state.records.length;
  $("statCheckups").textContent=state.checkups.filter(x=>x.date>=new Date().toISOString().slice(0,10)).length;
  $("statVaccines").textContent=state.vaccines.length;
  $("statAppointments").textContent=state.appointments.filter(x=>x.date>=new Date().toISOString().slice(0,10)).length;
  const upcoming=[...state.checkups.map(x=>({...x,type:"Checkup"})),...state.appointments.map(x=>({...x,type:"Appointment"}))].filter(x=>x.date>=new Date().toISOString().slice(0,10)).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,4);
  $("nextUp").innerHTML=upcoming.length?upcoming.map(x=>`<div class="item"><div><div class="item-title">${esc(x.title||x.hospital)}</div><div class="item-sub">${esc(x.type)} · ${fmtDateTime(x.date,x.time)}</div></div><span class="badge">${esc(x.place||"")}</span></div>`).join(""):`<div class="empty"><strong>No upcoming visits</strong>Add a checkup or appointment to see it here.</div>`;
  const rec=[...state.records].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,4);
  $("recentRecords").innerHTML=rec.length?rec.map(x=>`<div class="item"><div><div class="item-title">${esc(x.title)}</div><div class="item-sub">${fmtDate(x.date)} · ${esc(x.place)}</div></div><span class="badge">${esc(x.type)}</span></div>`).join(""):`<div class="empty"><strong>No records yet</strong>Your saved reports will appear here.</div>`;
}
function renderRecords(){
  $("recordsList").innerHTML=state.records.length?state.records.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(x=>`<article class="record-card"><div class="record-icon">▣</div><h3>${esc(x.title)}</h3><div class="record-meta">${esc(x.type)}<br>${fmtDate(x.date)} · ${esc(x.place||"No place added")}<br>${esc(x.notes||"")}</div><div class="card-actions">${x.file?`<button class="small-btn" onclick="downloadData('${x.id}')">Open file</button>`:""}<button class="small-btn danger" onclick="removeItem('records','${x.id}')">Delete</button></div></article>`).join(""):`<div class="empty" style="grid-column:1/-1"><strong>No health records</strong>Upload a report, prescription or other document.</div>`;
}
function renderCheckups(){
  $("checkupsList").innerHTML=state.checkups.length?state.checkups.slice().sort((a,b)=>a.date.localeCompare(b.date)).map(x=>`<article class="record-card"><div class="record-icon">◷</div><h3>${esc(x.title)}</h3><div class="record-meta">${fmtDateTime(x.date,x.time)}<br>${esc(x.place||"Place not specified")}<br>${esc(x.notes||"")}</div><div class="card-actions"><button class="small-btn danger" onclick="removeItem('checkups','${x.id}')">Delete</button></div></article>`).join(""):`<div class="empty" style="grid-column:1/-1"><strong>No scheduled checkups</strong>Keep your next visit in Sattari.</div>`;
}
function renderVaccines(){
  $("vaccinesList").innerHTML=state.vaccines.length?state.vaccines.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(x=>`<article class="record-card"><div class="record-icon">✚</div><h3>${esc(x.name)}</h3><div class="record-meta">Given: ${fmtDate(x.date)}<br>${x.next?`Next dose: ${fmtDate(x.next)}<br>`:""}${esc(x.place||"")}<br>${esc(x.notes||"")}</div><div class="card-actions"><button class="small-btn danger" onclick="removeItem('vaccines','${x.id}')">Delete</button></div></article>`).join(""):`<div class="empty" style="grid-column:1/-1"><strong>No vaccinations saved</strong>Add your vaccination history and next-dose dates.</div>`;
}
function renderAppointments(){
  $("appointmentsList").innerHTML=state.appointments.length?state.appointments.slice().sort((a,b)=>a.date.localeCompare(b.date)).map(x=>`<article class="record-card"><div class="record-icon">□</div><h3>${esc(x.hospital)}</h3><div class="record-meta">${esc(x.reason||"Appointment")}<br>${fmtDateTime(x.date,x.time)}<br>${esc(x.place||"")} · Fee: ₹${esc(x.fee||"0")}</div><div class="card-actions"><button class="small-btn danger" onclick="removeItem('appointments','${x.id}')">Delete</button></div></article>`).join(""):`<div class="empty" style="grid-column:1/-1"><strong>No appointments</strong>Add your hospital or clinic visits here.</div>`;
}
function renderProfile(){
  const u=state.user;if(!u)return;
  $("profileName").value=u.name||"";$("profileEmail").value=u.email||"";$("profileDob").value=u.dob||"";$("profileBlood").value=u.blood||"";$("profileEmergency").value=u.emergency||"";
  $("profilePhotoLarge").innerHTML=u.photo?`<img src="${u.photo}" alt="Profile">`:initials(u.name);
}
function renderAll(){if(!state.user){$("authView").classList.remove("hidden");$("appView").classList.add("hidden");return}$("authView").classList.add("hidden");$("appView").classList.remove("hidden");renderHeader();renderDashboard();renderRecords();renderCheckups();renderVaccines();renderAppointments();renderProfile()}

function formTemplate(title,fields,submitText,handler){
  openModal(`<h2>${title}</h2><form id="modalForm" class="form-grid">${fields.join("")}<div class="full form-actions"><button type="button" class="small-btn" onclick="closeModal()">Cancel</button><button class="primary">${submitText}</button></div></form>`);
  $("modalForm").onsubmit=e=>{e.preventDefault();handler(new FormData(e.target));closeModal();save();toast("Saved to Sattari")};
}
const inp=(name,label,type="text",req=false,cls="")=>`<label class="${cls}">${label}<input name="${name}" type="${type}" ${req?"required":""}></label>`;

$("addRecordBtn").onclick=()=>formTemplate("Add health record",[
 inp("title","Title","text",true),inp("type","Type (report / prescription / scan)","text",true),
 inp("date","Date","date",true),inp("place","Hospital / clinic / place"),
 inp("notes","Notes","text",false,"full"),
 `<label class="full">Document/photo<input name="file" type="file" accept="image/*,.pdf,.doc,.docx"></label>`
],"Save record",async f=>{
  let file=null;if(f.get("file")?.size){const b=await readFile(f.get("file"));file={name:f.get("file").name,data:b}}
  state.records.push({id:crypto.randomUUID(),title:f.get("title"),type:f.get("type"),date:f.get("date"),place:f.get("place"),notes:f.get("notes"),file});
});
$("addCheckupBtn").onclick=()=>formTemplate("Schedule checkup",[
 inp("title","What checkup?","text",true),inp("date","Date","date",true),inp("time","Time","time",true),inp("place","Hospital / clinic / place"),inp("notes","Notes","text",false,"full")
],"Schedule",f=>state.checkups.push({id:crypto.randomUUID(),title:f.get("title"),date:f.get("date"),time:f.get("time"),place:f.get("place"),notes:f.get("notes")}));
$("addVaccineBtn").onclick=()=>formTemplate("Add vaccination",[
 inp("name","Vaccine name","text",true),inp("date","Date given","date",true),inp("next","Next dose / booster","date"),inp("place","Hospital / clinic / place"),inp("notes","Notes","text",false,"full")
],"Save vaccination",f=>state.vaccines.push({id:crypto.randomUUID(),name:f.get("name"),date:f.get("date"),next:f.get("next"),place:f.get("place"),notes:f.get("notes")}));
$("addAppointmentBtn").onclick=()=>formTemplate("Add appointment",[
 inp("hospital","Hospital / clinic","text",true),inp("reason","Reason / department"),inp("date","Date","date",true),inp("time","Time","time",true),inp("place","Place / address"),inp("fee","Fee (₹)","number"),inp("notes","Notes","text",false,"full")
],"Save appointment",f=>state.appointments.push({id:crypto.randomUUID(),hospital:f.get("hospital"),reason:f.get("reason"),date:f.get("date"),time:f.get("time"),place:f.get("place"),fee:f.get("fee"),notes:f.get("notes")}));

function readFile(file){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(file)})}
window.downloadData=function(id){
 const x=state.records.find(r=>r.id===id);if(!x?.file)return;
 const a=document.createElement("a");a.href=x.file.data;a.download=x.file.name;a.click()
}
window.removeItem=function(type,id){if(confirm("Delete this item?")){state[type]=state[type].filter(x=>x.id!==id);save();toast("Deleted")}}

$("registerForm").onsubmit=async e=>{
 e.preventDefault();const f=new FormData(e.target);let photo=null;
 if($("regPhoto").files[0])photo=await readFile($("regPhoto").files[0]);
 state.user={name:f.get("name"),email:f.get("email"),password:f.get("password"),photo};
 save();showPage("dashboard");toast("Welcome to Sattari")
};
$("profileForm").onsubmit=async e=>{
 e.preventDefault();const u=state.user;u.name=$("profileName").value;u.email=$("profileEmail").value;u.dob=$("profileDob").value;u.blood=$("profileBlood").value;u.emergency=$("profileEmergency").value;
 if($("profilePhoto").files[0])u.photo=await readFile($("profilePhoto").files[0]);save();toast("Profile updated")
};
$("logoutBtn").onclick=()=>{state.user=null;save();location.reload()};
$("shareBtn").onclick=()=>{
 const u=state.user;const text=`SATTARI HEALTH SUMMARY\n\nName: ${u.name}\nBlood group: ${u.blood||"Not added"}\nHealth records: ${state.records.length}\nVaccinations: ${state.vaccines.length}\nUpcoming checkups: ${state.checkups.length}\nUpcoming appointments: ${state.appointments.length}\n\nGenerated by Sattari.`;
 if(navigator.share)navigator.share({title:"Sattari Health Summary",text});else{navigator.clipboard?.writeText(text);toast("Summary copied to clipboard")}
};

renderAll();
