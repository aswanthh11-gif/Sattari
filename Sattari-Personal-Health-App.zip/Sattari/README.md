# Sattari — Personal Health

A responsive prototype for the Sattari personal health organizer.

## Included
- Account creation with name, email, password and profile photo
- Personal profile
- Health records with date/place and uploaded PDF/image/document
- Upcoming checkup scheduling
- Vaccination history and next-dose date
- Appointment records with date, time, place and fee
- One-page shareable health summary via device share or clipboard
- Local browser persistence
- Responsive mobile/desktop UI
- Sattari logo and blue visual theme

## Run
Open `index.html` in a modern browser.

## Important for a real health product
This build is a local prototype. Real medical use should add secure authentication, encrypted server-side storage, access controls, audit logs, encrypted document storage, consent-based sharing, backups, account recovery, and compliance/privacy review appropriate to the countries where it is offered. Hospital appointment booking would also require integrations with actual hospital/provider systems.
